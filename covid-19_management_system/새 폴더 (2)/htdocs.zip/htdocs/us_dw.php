<html>
  <head>
     <META http-eqiuiv="content-type" content="text/html; charset=utf-8">
  </head>
  <body>
    
    <form action="us_DW_result.php" method="POST">
	  <h1>Social Distancing Level Set-Up</h1>
	  - Set-Up<br>
	  Social Distancing Level:<INPUT TYPE = "text" NAME="distance_working" > <br>
	  
	  
      <br><br>
      <input type="submit" VALUE="set-up">
    </form>
  </body>
</html>
<?php 
   echo "<br> <a href='index_kor.php'> <--이전화면</a>"; 
?>