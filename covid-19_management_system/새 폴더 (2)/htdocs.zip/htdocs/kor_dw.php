<html>
  <head>
     <META http-eqiuiv="content-type" content="text/html; charset=utf-8">
  </head>
  <body>
    
    <form action="kor_DW_result.php" method="POST">
	  <h1>거리두기 단계 변경</h1>
	  - 변경<br>
	  거리두기 단계:<INPUT TYPE = "text" NAME="distance_working" > <br>
	  
	  
      <br><br>
      <input type="submit" VALUE="변경">
    </form>
  </body>
</html>
<?php 
   echo "<br> <a href='index_kor.php'> <--이전화면</a>"; 
?>