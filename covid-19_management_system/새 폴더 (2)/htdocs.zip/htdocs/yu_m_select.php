<html>
   <head>
      <META http-eqiuiv="content-type" content="text/html; charset=utf-8">
   </head>
   <body>
      <h1> 모더나 접종 </h1>
      <FORM METHOD="post" ACTION="yu_m_result.php">
         이름 : <INPUT TYPE ="text" NAME="name" VALUE=>
         주민등록번호 : <INPUT TYPE ="text" NAME="ssn" VALUE=>
         <INPUT TYPE ="submit" VALUE="접종">
      </FORM>
   <body>
</html>