<html>
  <head>
     <META http-eqiuiv="content-type" content="text/html; charset=utf-8">
  </head>
  <body>
    
    <form action="american_insert_result.php" method="POST">
	  <h1>National Information Add</h1>
	  <h3>- Information Add</h3>
	  Name:<INPUT TYPE = "text" NAME="name" > <br>
	  Ssn:<INPUT TYPE = "text" NAME="ssn" > <br>
	  Sex:<INPUT TYPE = "text" NAME="sex" > <br>
	  Phone_Number:<INPUT TYPE = "text" NAME="phone_number" > <br>
	  Location:<INPUT TYPE = "text" NAME="location" > <br>
	  
      <br><br>
      <input type="submit" VALUE="Information_Add">
    </form>
  </body>
</html>
<?php 
   echo "<br> <a href='american.php'> <--Previous Screen</a>"; 
   echo "<br> <a href='index_us.php'> <--Initial Screen</a>";
?>

