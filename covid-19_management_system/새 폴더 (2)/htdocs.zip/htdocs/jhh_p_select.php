<html>
   <head>
      <META http-eqiuiv="content-type" content="text/html; charset=utf-8">
   </head>
   <body>
      <h1> Vaccination Pfizer </h1>
      <FORM METHOD="post" ACTION="jhh_p_result.php">
         Name : <INPUT TYPE ="text" NAME="name" VALUE=>
         Ssn : <INPUT TYPE ="text" NAME="ssn" VALUE=>
         <INPUT TYPE ="submit" VALUE="vaccination">
      </FORM>
   <body>
</html>