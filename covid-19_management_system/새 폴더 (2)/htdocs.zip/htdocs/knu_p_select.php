<html>
   <head>
      <META http-eqiuiv="content-type" content="text/html; charset=utf-8">
   </head>
   <body>
      <h1> 화이자 접종 </h1>
      <FORM METHOD="post" ACTION="knu_p_result.php">
         이름 : <INPUT TYPE ="text" NAME="name" VALUE=>
         주민등록번호 : <INPUT TYPE ="text" NAME="ssn" VALUE=>
         <INPUT TYPE ="submit" VALUE="접종">
      </FORM>
   <body>
</html>